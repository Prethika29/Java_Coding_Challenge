package com.hexaware.dao;

import com.hexaware.entity.CashDonation;
import com.hexaware.entity.ItemDonation;
import com.hexaware.util.DBConnUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DonationDao {

    // Method to record cash donation into the database
    public void recordDonation(CashDonation cashDonation) {
        Connection connection = DBConnUtil.getConnection();
        PreparedStatement preparedStatement = null;

        try {
            String insertSQL = "INSERT INTO donations (donor_name, amount, donation_date) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(insertSQL);

            // Setting parameters for the prepared statement
            preparedStatement.setString(1, cashDonation.getDonorName());  // donorName
            preparedStatement.setDouble(2, cashDonation.getAmount());     // amount
            preparedStatement.setString(3, cashDonation.getDonationDate().toString());  // donationDate

            // Execute the query
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to record item donation into the database
    public void recordDonation(ItemDonation itemDonation) {
        Connection connection = DBConnUtil.getConnection();
        PreparedStatement preparedStatement = null;

        try {
            String insertSQL = "INSERT INTO donations (donor_name, amount, item_description) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(insertSQL);

            // Setting parameters for the prepared statement
            preparedStatement.setString(1, itemDonation.getDonorName());  // donorName
            preparedStatement.setDouble(2, itemDonation.getAmount());     // amount
            preparedStatement.setString(3, itemDonation.getItemDescription());  // itemDescription

            // Execute the query
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
