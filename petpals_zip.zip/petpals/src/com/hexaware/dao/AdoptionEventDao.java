package com.hexaware.dao;

import com.hexaware.entity.AdoptionEvent;
import com.hexaware.util.DBConnUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AdoptionEventDao {

    // Method to register a participant in an adoption event
    public void registerParticipant(AdoptionEvent event) {
        Connection conn = DBConnUtil.getConnection();
        PreparedStatement preparedStatement = null;

        try {
            // SQL query to insert participant details into the database
            String sql = "INSERT INTO participants (event_name, participant_name) VALUES (?, ?)";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, event.getEventName());
            preparedStatement.setString(2, event.getParticipantName());

            // Execute the query
            preparedStatement.executeUpdate();
            System.out.println("Participant successfully registered for the event!");

        } catch (SQLException e) {
            System.out.println("Error while registering participant: " + e.getMessage());
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }

    // Method to display all adoption events from the database
    public void displayAllEvents() {
        Connection conn = DBConnUtil.getConnection();
        PreparedStatement preparedStatement = null;
        try {
            String sql = "SELECT * FROM adoption_events";
            preparedStatement = conn.prepareStatement(sql);
            var resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                System.out.println("Event Name: " + resultSet.getString("event_name"));
                System.out.println("Event Date: " + resultSet.getString("event_date"));
                System.out.println("------------");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching adoption events: " + e.getMessage());
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
}
