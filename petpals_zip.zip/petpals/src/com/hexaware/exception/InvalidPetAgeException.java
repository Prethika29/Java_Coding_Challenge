package com.hexaware.exception;

// Custom exception for invalid pet age
public class InvalidPetAgeException extends Exception {

    // Define a unique serialVersionUID for serialization
    private static final long serialVersionUID = 1L;

    public InvalidPetAgeException(String message) {
        super(message);
    }
}
