package com.hexaware.exception;

// Custom exception for file handling errors
public class FileHandlingException extends Exception {
    private static final long serialVersionUID = 1L;

    // Constructor to pass error message
    public FileHandlingException(String message) {
        super(message);
    }
}
