package com.hexaware.main;

import com.hexaware.dao.PetDao;
import com.hexaware.dao.DonationDao;
import com.hexaware.dao.AdoptionEventDao;
import com.hexaware.entity.Pet;
import com.hexaware.entity.CashDonation;
import com.hexaware.entity.AdoptionEvent;
import com.hexaware.exception.*;

import java.util.Scanner;
import java.util.List;

public class MainModule {

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        while (true) {
            // Menu for user interaction
            System.out.println("Menu:");
            System.out.println("1. Add Pet with Age");
            System.out.println("2. Display Pet Listings");
            System.out.println("3. Make Cash Donation");
            System.out.println("4. Read Pet Data from File");
            System.out.println("5. Register for Adoption Event");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume the newline
            
            switch (choice) {
                case 1:
                    addPet();
                    break;
                case 2:
                    displayPetListings();
                    break;
                case 3:
                    makeCashDonation();
                    break;
                case 4:
                    // Implement file reading logic if needed
                    break;
                case 5:
                    registerForAdoptionEvent();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();  // Close the scanner resource
                    return; // Exit the program
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }

    // Method to add a pet with valid age
    private static void addPet() {
        try {
            System.out.print("Enter pet name: ");
            String name = scanner.nextLine();

            System.out.print("Enter pet age: ");
            int age = scanner.nextInt();
            scanner.nextLine();  // consume the newline

            // Validate age
            if (age <= 0) {
                throw new InvalidPetAgeException("Pet age must be a positive number.");
            }

            System.out.print("Enter pet breed: ");
            String breed = scanner.nextLine();

            Pet pet = new Pet(name, age, breed);

            // Save pet to the database
            PetDao petDao = new PetDao();
            petDao.addPetToDatabase(pet);

        } catch (InvalidPetAgeException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while adding the pet: " + e.getMessage());
        }
    }

    // Method to display all pets
    private static void displayPetListings() {
        try {
            PetDao petDao = new PetDao();
            List<Pet> pets = petDao.getAllPets();
            if (pets.isEmpty()) {
                System.out.println("No pets available.");
            } else {
                System.out.println("Available Pets:");
                for (Pet pet : pets) {
                    System.out.println(pet);
                }
            }
        } catch (Exception e) {
            System.out.println("Error retrieving pet listings: " + e.getMessage());
        }
    }

    // Method to make a cash donation
    private static void makeCashDonation() {
        try {
            System.out.print("Enter donor name: ");
            String donorName = scanner.nextLine();

            System.out.print("Enter donation amount: ");
            double amount = scanner.nextDouble();
            scanner.nextLine();  // consume the newline

            if (amount < 10) {
                throw new InsufficientFundsException("Minimum donation amount is $10.");
            }

            CashDonation donation = new CashDonation(donorName, amount);
            DonationDao donationDao = new DonationDao();
            donationDao.recordDonation(donation);

        } catch (InsufficientFundsException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while processing the donation: " + e.getMessage());
        }
    }

    // Method to register for an adoption event
    private static void registerForAdoptionEvent() {
        try {
            System.out.print("Enter adoption event name: ");
            String eventName = scanner.nextLine();

            System.out.print("Enter participant name: ");
            String participantName = scanner.nextLine();

            // Assuming AdoptionEvent constructor needs only event name and participant name
            AdoptionEvent event = new AdoptionEvent(eventName, participantName);
            AdoptionEventDao adoptionEventDao = new AdoptionEventDao();
            adoptionEventDao.registerParticipant(event);

            System.out.println("Successfully registered for the adoption event!");

        } catch (Exception e) {
            System.out.println("An error occurred while registering for the adoption event: " + e.getMessage());
        }
    }
}
