package com.hexaware.entity;


import java.util.ArrayList;
import java.util.List;

// Shelter to hold pets available for adoption
public class PetShelter {
    private List<Pet> availablePets = new ArrayList<>();

    public void addPet(Pet pet) {
        availablePets.add(pet);
        System.out.println(pet.getName() + " added to shelter.");
    }

    public void removePet(Pet pet) {
        availablePets.remove(pet);
        System.out.println(pet.getName() + " removed from shelter.");
    }

    public void listAvailablePets() {
        System.out.println("Available pets in shelter:");
        for (Pet pet : availablePets) {
            System.out.println(pet);
        }
    }
}
