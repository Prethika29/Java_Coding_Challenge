/* package com.hexaware.entity;

import java.time.LocalDateTime;

public class CashDonation extends Donation {

    private LocalDateTime donationDate;

    // Constructor to initialize donorName, amount, and donationDate
    public CashDonation(String donorName, double amount, LocalDateTime donationDate) {
        super(donorName, amount);  // Call parent constructor to set donorName and amount
        this.donationDate = donationDate;
    }

    // Override the recordDonation method from the Donation class
    @Override
    public void recordDonation() {
        // Display the donation information
        System.out.println("Cash donation recorded from " + getDonorName() + " of amount $" + getAmount() + " on " + donationDate);
    }

    // Getter and setter for donationDate
    public LocalDateTime getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(LocalDateTime donationDate) {
        this.donationDate = donationDate;
    }
}
*/
/*
package com.hexaware.entity;

import java.time.LocalDateTime;

public class CashDonation extends Donation {

    private LocalDateTime donationDate;

    // Constructor with three parameters
    public CashDonation(String donorName, double amount, LocalDateTime donationDate) {
        super(donorName, amount);
        this.donationDate = donationDate;
    }

    // Overloaded constructor with two parameters (donorName and amount)
    public CashDonation(String donorName, double amount) {
        super(donorName, amount);
        this.donationDate = LocalDateTime.now(); // Use the current date and time as default
    }

    @Override
    public void recordDonation() {
        System.out.println("Cash donation recorded from " + getDonorName() + " of amount $" + getAmount() + " on " + donationDate);
    }

    public LocalDateTime getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(LocalDateTime donationDate) {
        this.donationDate = donationDate;
    }
}
*/

package com.hexaware.entity;

import java.time.LocalDateTime;

public class CashDonation extends Donation {
    private LocalDateTime donationDate;

    // Constructor for CashDonation
    public CashDonation(String donorName, double amount, LocalDateTime donationDate) {
        super(donorName, amount);
        this.donationDate = donationDate;
    }

    // Constructor for CashDonation without donation date
    public CashDonation(String donorName, double amount) {
        super(donorName, amount);
    }

    @Override
    public void recordDonation() {
        System.out.println("Cash donation recorded from " + getDonorName() + " of amount $" + getAmount() + " on " + donationDate);
    }

    public LocalDateTime getDonationDate() {
        return donationDate;
    }

    @Override
    public String toString() {
        return "CashDonation [donationDate=" + donationDate + "]";
    }
}

