package com.hexaware.entity;



//Interface representing adoptable entities
public interface IAdoptable {
 void adopt(); // Method to handle adoption process
}

