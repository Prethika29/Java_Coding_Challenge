package com.hexaware.entity;

public class AdoptionEvent {
    private String eventName;
    private String participantName;

    // Constructor
    public AdoptionEvent(String eventName, String participantName) {
        this.eventName = eventName;
        this.participantName = participantName;
    }

    // Getter and Setter for eventName
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    // Getter and Setter for participantName
    public String getParticipantName() {
        return participantName;
    }

    public void setParticipantName(String participantName) {
        this.participantName = participantName;
    }

    @Override
    public String toString() {
        return "AdoptionEvent [eventName=" + eventName + ", participantName=" + participantName + "]";
    }
}
