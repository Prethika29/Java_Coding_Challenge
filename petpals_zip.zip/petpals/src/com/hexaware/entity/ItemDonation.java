/* package com.hexaware.entity;

// Concrete class for item donations
public class ItemDonation extends Donation {
    private String itemDescription;

    public ItemDonation(String donorName, double amount, String itemDescription) {
        super(donorName, amount);  // Call parent constructor to set donor info and amount
        this.itemDescription = itemDescription;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

}
*/
/*
package com.hexaware.entity;

import com.hexaware.dao.DonationDao;

public class ItemDonation extends Donation {

    private String itemName;

    // Constructor for ItemDonation
    public ItemDonation(String donorName, String itemName) {
        super(donorName);
        this.itemName = itemName;
    }

    public String getItemName() {
        return itemName;
    }

    @Override
    public void recordDonation() {
        // Insert item donation into the database using DonationDao
        DonationDao donationDao = new DonationDao();
        donationDao.recordItemDonation(this);  // Implement your logic for item donation
    }
}
*/

package com.hexaware.entity;

public class ItemDonation extends Donation {
    private String itemDescription;

    // Constructor for ItemDonation
    public ItemDonation(String donorName, double amount, String itemDescription) {
        super(donorName, amount);  // Calling parent constructor
        this.itemDescription = itemDescription;
    }

    @Override
    public void recordDonation() {
        System.out.println("Item donation recorded from " + getDonorName() + " of amount $" + getAmount() + " with item: " + itemDescription);
    }

    public String getItemDescription() {
        return itemDescription;
    }

    @Override
    public String toString() {
        return "ItemDonation [itemDescription=" + itemDescription + "]";
    }
}
