

package com.hexaware.entity;

import java.time.LocalDateTime;

public class CashDonation extends Donation {
    private LocalDateTime donationDate;

    // Constructor for CashDonation
    public CashDonation(String donorName, double amount, LocalDateTime donationDate) {
        super(donorName, amount);
        this.donationDate = donationDate;
    }

    // Constructor for CashDonation without donation date
    public CashDonation(String donorName, double amount) {
        super(donorName, amount);
    }

    @Override
    public void recordDonation() {
        System.out.println("Cash donation recorded from " + getDonorName() + " of amount $" + getAmount() + " on " + donationDate);
    }

    public LocalDateTime getDonationDate() {
        return donationDate;
    }

    @Override
    public String toString() {
        return "CashDonation [donationDate=" + donationDate + "]";
    }
}

