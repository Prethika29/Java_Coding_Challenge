
package com.hexaware.entity;

public class ItemDonation extends Donation {
    private String itemDescription;

    // Constructor for ItemDonation
    public ItemDonation(String donorName, double amount, String itemDescription) {
        super(donorName, amount);  // Calling parent constructor
        this.itemDescription = itemDescription;
    }

    @Override
    public void recordDonation() {
        System.out.println("Item donation recorded from " + getDonorName() + " of amount $" + getAmount() + " with item: " + itemDescription);
    }

    public String getItemDescription() {
        return itemDescription;
    }

    @Override
    public String toString() {
        return "ItemDonation [itemDescription=" + itemDescription + "]";
    }
}
