package com.hexaware.entity;

// Dog class inherits from Pet
public class Dog extends Pet {
    private String dogBreed;

    // Default Constructor
    public Dog() {
		super();
		// TODO Auto-generated constructor stub
	}

    // Parameterized Constructor
	public Dog(String name, int age, String breed) {
		super(name, age, breed);
		// TODO Auto-generated constructor stub
	}

	public Dog(String name, int age, String breed, String dogBreed) {
        super(name, age, breed);
        this.dogBreed = dogBreed;
    }

    public String getDogBreed() { return dogBreed; }
    public void setDogBreed(String dogBreed) { this.dogBreed = dogBreed; }

    @Override
    public String toString() {
        return super.toString() + ", DogBreed=" + dogBreed;
    }
}
