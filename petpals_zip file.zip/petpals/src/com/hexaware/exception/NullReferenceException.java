package com.hexaware.exception;

// Custom exception for handling null references in pet data
public class NullReferenceException extends Exception {
    private static final long serialVersionUID = 1L;

    public NullReferenceException(String message) {
        super(message);
    }
}
