package com.hexaware.exception;

// Custom exception for adoption errors
public class AdoptionException extends Exception {
    private static final long serialVersionUID = 1L;

    // Constructor to pass error message
    public AdoptionException(String message) {
        super(message);
    }
}
