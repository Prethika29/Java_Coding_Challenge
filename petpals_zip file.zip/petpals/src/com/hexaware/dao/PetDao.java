

package com.hexaware.dao;

import com.hexaware.entity.Pet;
import com.hexaware.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PetDao {

    // Method to add a new pet to the database
    public void addPetToDatabase(Pet pet) {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Get database connection
            conn = DBConnUtil.getConnection();
            
            // SQL query to insert a pet
            String sql = "INSERT INTO pets (name, age, breed) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, pet.getName());
            stmt.setInt(2, pet.getAge());
            stmt.setString(3, pet.getBreed());

            // Execute the query
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Pet added successfully.");
            } else {
                System.out.println("Failed to add pet.");
            }

        } catch (SQLException e) {
            System.out.println("Error adding pet to the database: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }

    // Method to retrieve all pets from the database
    public List<Pet> getAllPets() {
        List<Pet> petList = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Get database connection
            conn = DBConnUtil.getConnection();
            
            // SQL query to retrieve pets
            String sql = "SELECT * FROM pets";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            // Iterate through the result set and create Pet objects
            while (rs.next()) {
                Pet pet = new Pet();
                pet.setName(rs.getString("name"));
                pet.setAge(rs.getInt("age"));
                pet.setBreed(rs.getString("breed"));
                petList.add(pet);
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving pets from the database: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
        return petList;
    }
}
